<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1>Hola vista nueva</h1>
        </div>
    </main>
