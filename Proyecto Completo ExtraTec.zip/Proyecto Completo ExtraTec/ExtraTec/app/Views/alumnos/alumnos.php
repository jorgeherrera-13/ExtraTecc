<!-- Este DIV se cierra en el footer.php -->
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <!-- Título de la pantalla, que viene desde Programas (Controllers) -->
            <h1 class="mt-4"><?php echo $titulo; ?> </h1>

            <div>
                <p>
                    <!-- Botones de Agregar y Eliminadas -->
                    <a href="<?php echo base_url(); ?>alumnos/nuevo" class="btn btn-outline-primary btn"><i class="fa-regular fa-square-plus fa-fade"></i> Agregar </a>
                    <a href="<?php echo base_url(); ?>alumnos/eliminados" class="btn btn-outline-secondary btn"> <i class="fa-solid fa-ban fa-fade"></i> Eliminados </a>
                </p>
            </div>

            <!-- Creación de la tabla para mostrar los registros -->
            <div class="card mb-4">
                <div class="card-body">
                    <table id="datatablesSimple">
                        <thead>
                            <!-- Encabezados de la tabla -->
                            <tr>
                                <th>id</th>
                                <th>Nombre</th>
                                <th>Primer Apellido</th>
                                <th>Segundo Apellido</th>
                                <th>Fecha de Nacimiento</th>
                                <th>Género</th>
                                <th>E-mail</th>
                                <th>Teléfono</th>
                                <th>Estado</th>
                                <th>Fecha de Ingreso</th>
                                <th>Programa</th>
                                <th></th>
                                <th></th>
                                
                            </tr>
                        </thead>

                        <!-- Presentación de la información obtenida desde la carpeta de Controllers->Programas  -->
                        <!-- a través del método o función index y de la variable "programas" -->
                        <tbody>
                            <?php foreach ($datos as $registro) { ?>
                                <tr>
                                    <td><?php echo $registro['idalumno']; ?> </td>
                                    <td><?php echo $registro['nombre']; ?> </td>
                                    <td><?php echo $registro['primerapellido']; ?> </td>
                                    <td><?php echo $registro['segundoapellido']; ?> </td>
                                    <td><?php echo $registro['fechanacimiento']; ?> </td>
                                    <td><?php echo $registro['genero']; ?> </td>
                                    <td><?php echo $registro['email']; ?> </td>
                                    <td><?php echo $registro['telefono']; ?> </td>
                                    <td><?php echo $registro['idestado']; ?> </td>
                                    <td><?php echo $registro['fechaingreso']; ?> </td>
                                    <td><?php echo $registro['idprograma']; ?> </td>

                                    <!-- Botón de Editar -->
                                    <td><a href="<?php echo base_url() . 'alumnos/editar/' . $registro['idalumno']; ?>" class="btn btn-outline-warning">
                                            <i class="fas fa-pencil-alt"></i> </a> 
                                    </td>

                                    <!-- Botón de Eliminar -->
                                    <td>
                                        <button data-bs-id="<?php echo $registro['idalumno']; ?>" data-bs-nombre="<?php echo $registro['nombre']; ?>" data-bs-toggle="modal" data-bs-target="#backModal" rel='tooltip' data-placement="top" class="btn btn-outline-danger">
                                            <i class="fas fa-trash"></i> 
                                        </button>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                        <tfoot>
                            <tr>
                            <th>id</th>
                                <th>Nombre</th>
                                <th>Primer Apellido</th>
                                <th>Segundo Apellido</th>
                                <th>Fecha de Nacimiento</th>
                                <th>Género</th>
                                <th>E-mail</th>
                                <th>Teléfono</th>
                                <th>Estado</th>
                                <th>Fecha de Ingreso</th>
                                <th>Programa</th>
                                <th></th>
                                <th></th>                                                           
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- Modal Eliminar -->
    <div class="modal fade" id="backModal" tabindex="-1" role="dialog" aria-labelledby="backModal" aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">¿Desea eliminar el alumno <b><span></span>?</b></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-footer">
                    <form id="backForm" data-bs-action="<?php echo base_url() . 'alumnos/eliminar/' ?>" action="" method="post">
                        <button type="submit" class="btn btn-primary">Sí</button>
                    </form>
                    <button class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </div>
    </div>
</div>
