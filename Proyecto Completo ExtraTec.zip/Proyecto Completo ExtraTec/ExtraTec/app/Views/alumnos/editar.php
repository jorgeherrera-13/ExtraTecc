<div id="layoutSidenav_content">
   <!-- Este DIV se cierra en el footer.php -->
   <main>
      <div class="container-fluid">

         <!-- Título de la pantalla, que viene desde Programas (Controllers) -->
         <h3 class="mt-4"><?php echo $titulo; ?></h3>



         <!-- Acciones a realizar en el método Actualizar de Programas (Controller) -->
         <form method="POST" action="<?php echo base_url(); ?>alumnos/actualizar" autocomplete="off">
            <div class="card mb-4">
               <div class="card-body">

                  <input type="hidden" value="<?php echo $alumnos['idalumno']; ?>" name="id" />

                  <!-- Diseño de la pantalla -->
                  <div class="form-group">
                     <div class="row">

                     <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo Programas -->
                                    <label> Nombre: </label>
                                    <!-- Cuadro de texto para ingresar el nombre de Programas-->
                                    <input class="form-control" id="nombre" name="nombre" type="text" value="<?php echo $alumnos['nombre'] ?>" autofocus />
                                </div>

                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo Abreviatura -->
                                    <label> Primer Apellido: </label>
                                    <!-- Cuadro de texto para ingresar la abreviatura-->
                                    <input class="form-control" id="primerapellido" name="primerapellido" type="text" value="<?php echo $alumnos['primerapellido'] ?>"/>
                                </div>

                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo Abreviatura -->
                                    <label> Segundo Apellido: </label>
                                    <!-- Cuadro de texto para ingresar la abreviatura-->
                                    <input class="form-control" id="segundoapellido" name="segundoapellido" type="text" value="<?php echo $alumnos['segundoapellido'] ?>"  />
                                </div>

                            </div>
                                <div class="row">

                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo Abreviatura -->
                                    <label> Fecha Nacimiento: </label>
                                    <!-- Cuadro de texto para ingresar la abreviatura-->
                                    <input class="form-control" id="fechanacimiento" name="fechanacimiento" type="text" value="<?php echo $alumnos['fechanacimiento'] ?>" />
                                </div>

                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo Abreviatura -->
                                    <label> Genero: </label>
                                    <!-- Cuadro de texto para ingresar la abreviatura-->
                                    <input class="form-control" id="genero" name="genero" type="text" value="<?php echo $alumnos['genero']?>" />
                                </div>

                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo Abreviatura -->
                                    <label> Email: </label>
                                    <!-- Cuadro de texto para ingresar la abreviatura-->
                                    <input class="form-control" id="email" name="email" type="text" value="<?php echo $alumnos['email'] ?>"  />
                                </div>

                            <div class="row">

                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo Abreviatura -->
                                    <label> Telefono: </label>
                                    <!-- Cuadro de texto para ingresar la abreviatura-->
                                    <input class="form-control" id="telefono" name="telefono" type="text" value="<?php echo $alumnos['telefono'] ?>"  />
                                </div>

                                <div class="col-12 col-sm-4">
                                    <label> Estado de Residencia: </label>
                                    <!-- Combo para seleccionar al autor principal del libro  -->
                                    <select class="form-control" id="idestado" name="idestado">
                                        <option value=""> Selecciona el estado </option>
                                        <<?php
                                            if (isset($estados) && is_array($estados)) {
                                                foreach ($estados as $estado) {
                                            ?> <option value="<?php echo $estado['idestado']; ?>"><?php echo $estado['estado']; ?> </option>
                                    <?php
                                                }
                                            }
                                    ?>

                                    </select>
                                </div>

                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo Abreviatura -->
                                    <label> Fecha de Ingreso: </label>
                                    <!-- Cuadro de texto para ingresar la abreviatura-->
                                    <input class="form-control" id="fechaingreso" name="fechaingreso" type="text" value="<?php echo $alumnos['fechaingreso'] ?>"  />
                                </div>
                            </div>

                            <div class="col-12 col-sm-6">
                                    <label> Programa: </label>
                                    <!-- Combo para seleccionar al autor principal del libro  -->
                                    <select class="form-control" id="idprograma" name="idprograma">
                                        <option value=""> Selecciona el Programa a registrarse </option>
                                        <<?php
                                            if (isset($programas) && is_array($programas)) {
                                                foreach ($programas as $programa) {
                                            ?> <option value="<?php echo $programa['idprograma']; ?>"><?php echo $programa['nombreprograma']; ?></option>
                                    <?php
                                                }
                                            }
                                    ?>
                                    </select>
                                </div>
                  </div>
                  <!-- Espacio entre el diseño y los botones -->
                  <p></p>

                  <!-- Botón de Regresar con acción a la pantralla de Grados -->
                  <a href="<?php echo base_url(); ?>alumnos" class="btn btn-outline-primary"><i class="fa-solid fa-arrow-left fa-fade"></i> Regresar</a>
                  <!-- Botón de Guardar -->
                  <button type="submit" class="btn btn-outline-success"><i class="fa-regular fa-floppy-disk fa-fade"></i></i> Guardar</button>
               </div>
            </div>
         </form>
      </div>
   </main>