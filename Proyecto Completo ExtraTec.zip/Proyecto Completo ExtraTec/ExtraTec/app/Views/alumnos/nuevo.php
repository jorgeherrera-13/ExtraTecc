<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <!-- Título de la pantalla, que viene desde Carreras (Controllers) -->
            <h1 class="mt-4"><?php echo $titulo; ?> </h1>

            <!-- Validación de campos a través del constructor  -->
            <?php if (isset($validation)) { ?>
                <div class="alert alert-danger">
                    <?php echo $validation->listErrors(); ?>
                </div>
            <?php } ?>


            <form method="post" action="<?php echo base_url(); ?>alumnos/insertar" autocomplete="off">

                <div class="card mb-4">
                    <div class="card-body">
                        <!-- Diseño de la pantalla -->
                        <div class="form-group">
                            <div class="row">
                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo Titulo -->
                                    <label> Nombre: </label>
                                    <!-- Cuadro de texto para ingresar el nombre de la Titulo del libro-->
                                    <input class="form-control" id="nombre" name="nombre" type="text" placeholder="Ingrese el nombre del alumno" autofocus required />
                                </div>

                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo ISBN -->
                                    <label> Primer Apellido: </label>
                                    <!-- Cuadro de texto para ingresar el nombre del ISBN-->
                                    <input class="form-control" id="primerapellido" name="primerapellido" type="text" placeholder="Ingrese el apellido del alumno" required />
                                </div>

                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo ISBN -->
                                    <label> Segundo Apellido: </label>
                                    <!-- Cuadro de texto para ingresar el nombre del ISBN-->
                                    <input class="form-control" id="segundoapellido" name="segundoapellido" type="text" placeholder="Ingrese el apellido del alumno" required />
                                </div>

                            </div>
                        </div>

                            <div class="row">
                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo ISBN -->
                                    <label> fecha de nacimiento: </label>
                                    <!-- Cuadro de texto para ingresar el nombre del ISBN-->
                                    <input class="form-control" id="fechanacimiento" name="fechanacimiento" type="text" placeholder="formato: año-mes-dia" required />
                                </div>
            
                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo ISBN -->
                                    <label> Género: </label>
                                    <!-- Cuadro de texto para ingresar el nombre del ISBN-->
                                    <input class="form-control" id="genero" name="genero" type="text" placeholder="Ingrese el genero del alumno" required />
                                </div>

                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo ISBN -->
                                    <label> E-mail: </label>
                                    <!-- Cuadro de texto para ingresar el nombre del ISBN-->
                                    <input class="form-control" id="email" name="email" type="text" placeholder="Ingrese el e-mail del alumno" required />
                                </div>

                            <div class="row">
                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo ISBN -->
                                    <label> Teléfono: </label>
                                    <!-- Cuadro de texto para ingresar el nombre del ISBN-->
                                    <input class="form-control" id="telefono" name="telefono" type="text" placeholder="Ingrese el teléfono del alumno" required />
                                </div>

                                <div class="col-12 col-sm-4">
                                    <label> Estado de Residencia: </label>
                                    <!-- Combo para seleccionar al autor principal del libro  -->
                                    <select class="form-control" id="idestado" name="idestado">
                                        <option value=""> Selecciona el estado </option>
                                        <<?php
                                            if (isset($estados) && is_array($estados)) {
                                                foreach ($estados as $estado) {
                                            ?> <option value="<?php echo $estado['idestado']; ?>"><?php echo $estado['estado']; ?> </option>
                                    <?php
                                                }
                                            }
                                    ?>

                                    </select>
                                </div>

                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo ISBN -->
                                    <label> Fecha de Ingreso: </label>
                                    <!-- Cuadro de texto para ingresar el nombre del ISBN-->
                                    <input class="form-control" id="fechaingreso" name="fechaingreso" type="text" placeholder="formato: año-mes-dia" required />
                                </div>

                            <div class="row">

                                <div class="col-12 col-sm-6">
                                    <label> Programa: </label>
                                    <!-- Combo para seleccionar al autor principal del libro  -->
                                    <select class="form-control" id="idprograma" name="idprograma">
                                        <option value=""> Selecciona el Programa a registrarse </option>
                                        <<?php
                                            if (isset($programas) && is_array($programas)) {
                                                foreach ($programas as $programa) {
                                            ?> <option value="<?php echo $programa['idprograma']; ?>"><?php echo $programa['nombreprograma']; ?></option>
                                    <?php
                                                }
                                            }
                                    ?>

                                    </select>
                                </div>

                                <div class="col-12 col-sm-6">
                                    <!-- Etiqueta del campo Activo -->
                                    <label> Activo: </label>
                                    <!-- Cuadro de selección para el estado activo o inactivo -->
                                    <select class="form-control" id="activo" name="activo">
                                        <option value="1">Activo</option>
                                        <option value="0">Inactivo</option>
                                    </select>
                                </div>
                            </div>
                                        </div>
                        </div>
                        <p></p>
                        <!-- Botón de Regresar con acción a la pantralla de Libros -->
                        <a href="<?php echo base_url(); ?>alumnos" class="btn btn-outline-primary"><i class="fa-solid fa-arrow-left fa-fade"></i> Regresar</a>
                        <!-- Botón de Guardar -->
                        <button type="submit" class="btn btn-outline-success"><i class="fa-regular fa-floppy-disk fa-fade"></i> Guardar</button>
                    </div>
                </div>

            </form>
        </div>
    </main>