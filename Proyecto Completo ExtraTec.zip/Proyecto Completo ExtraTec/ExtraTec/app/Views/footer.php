<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; ITEL <?php echo date('Y');?>
            </div>
            <div>
                <a href="#">Privacy Policy</a>
                &middot;
                <a href="#">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer>
</div>
</div>
<script src="<?php echo base_url(); ?>js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url(); ?>js/scripts.js"></script>
<script src="<?php echo base_url(); ?>js/simple-datatables.min.js"></script>
<script src="<?php echo base_url(); ?>js/datatables-simple-demo.js"></script>
</body>

</html>
<!-- Script para activar un registro -->
<script>
    var backModal = document.getElementById('backModal')
    backModal.addEventListener('show.bs.modal', function(event) {
        var button = event.relatedTarget
        var id = button.getAttribute('data-bs-id')
        var nombre = button.getAttribute('data-bs-nombre')

        var modalTitle = backModal.querySelector('.modal-title span')
        modalTitle.textContent = nombre

        var backForm = backModal.querySelector('#backForm')
        var action = backForm.getAttribute("data-bs-action")

        // Utiliza una ruta relativa en lugar de la URL completa
        backForm.setAttribute("action", action + '/' + id)
    })
</script>