<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <!-- Título de la pantalla, que viene desde Programas (Controllers) -->
            <h1 class="mt-4"><?php echo $titulo; ?> </h1>

            <!-- Validación de campos a través del constructor del Controller -->
            <?php if (isset($validation)) { ?>
                <div class="alert alert-danger">
                    <?php echo $validation->listErrors(); ?>
                </div>
            <?php } ?>

            <form method="POST" action="<?php echo base_url(); ?>programas/insertar" autocomplete="off">
                <div class="card mb-4">
                    <div class="card-body">
                        <!-- Diseño de la pantalla -->
                        <div class="form-group">
                            <div class="row">
                                <div class="col-12 col-sm-6">
                                    <!-- Etiqueta del campo Programas -->
                                    <label> Programa: </label>
                                    <!-- Cuadro de texto para ingresar el nombre de Programas-->
                                    <input class="form-control" id="programa" name="programa" type="text" value="<?php echo set_value('programa') ?>"  placeholder="Ingrese el nombre del programa" autofocus />
                                </div>

                                <div class="col-12 col-sm-4">
                                    <!-- Etiqueta del campo Abreviatura -->
                                    <label> Código: </label>
                                    <!-- Cuadro de texto para ingresar la abreviatura-->
                                    <input class="form-control" id="codigo" name="codigo" type="text" value="<?php echo set_value('codigo') ?>"  placeholder="Ingrese el código del programa" />
                                </div>
                            </div>
                                <div class="row">

                                <div class="col-12 col-sm-3">
                                    <!-- Etiqueta del campo Abreviatura -->
                                    <label> Duración: </label>
                                    <!-- Cuadro de texto para ingresar la abreviatura-->
                                    <input class="form-control" id="duracion" name="duracion" type="text" value="<?php echo set_value('duracion') ?>"  placeholder="Ingrese la duración del programa" />
                                </div>
                               
                                <div class="col-12 col-sm-3">
                                    <!-- Etiqueta del campo Activo -->
                                    <label> Activo: </label>
                                    <!-- Cuadro de selección para el estado activo o inactivo -->
                                    <select class="form-control" id="activo" name="activo" required>
                                        <option value="1">Activo</option>
                                        <option value="0">Inactivo</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <p></p>
                        <!-- Botón de Regresar con acción a la pantralla de Grado -->
                        <a href="<?php echo base_url(); ?>programas" class="btn btn-outline-primary"><i class="fa-solid fa-arrow-left fa-fade"></i> Regresar</a>
                        <!-- Botón de Guardar -->
                        <button type="submit" class="btn btn-outline-success"><i class="fa-regular fa-floppy-disk fa-fade"></i> Guardar</button>
                    </div>
                </div>
            </form>
        </div>
    </main>