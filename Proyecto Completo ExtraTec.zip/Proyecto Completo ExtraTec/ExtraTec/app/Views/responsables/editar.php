<div id="layoutSidenav_content">
   <!-- Este DIV se cierra en el footer.php -->
   <main>
      <div class="container-fluid">

         <!-- Título de la pantalla, que viene desde Programas (Controllers) -->
         <h3 class="mt-4"><?php echo $titulo; ?></h3>



         <!-- Acciones a realizar en el método Actualizar de Programas (Controller) -->
         <form method="POST" action="<?php echo base_url(); ?>profesores/actualizar" autocomplete="off">
            <div class="card mb-4">
               <div class="card-body">

                  <input type="hidden" value="<?php echo $registro['idprofesor']; ?>" name="IDprofesor" />

                  <!-- Diseño de la pantalla -->
                  <div class="form-group">
                     <div class="row">

                        <div class="col-12 col-sm-4">

                           <label>Nombre:</label> <!-- Etiqueta de la Programa -->
                           <!-- Cuadro de texto para ingresar el programa -->
                           <input class="form-control" id="nombre" name="nombre" type="text" value="<?php echo $registro['nombre'] ?>"  required />
                        </div>
                        <div class="col-12 col-sm-4">
                           <label>Primer Apellido:</label> <!-- Etiqueta de la  -->
                           <!-- Cuadro de texto para ingresar la Codigo -->
                           <input class="form-control" id="PA" name="PA" type="text" value="<?php echo $registro['apellidopri'] ?>"  required />
                        </div>
                        <div class="col-12 col-sm-4">
                           <label>Segundo Apellido:</label> <!-- Etiqueta de la Duracion -->
                           <!-- Cuadro de texto para ingresar la duración -->
                           <input class="form-control" id="apellidoseg" name="apellidoseg" type="text" value="<?php echo $registro['apellidoseg'] ?>"  required />
                        </div>
                     </div>

                     </div>
                        <div class="row">

                           <div class="col-12 col-sm-4">
                              <!-- Etiqueta del campo Abreviatura -->
                              <label> Teléfono: </label>
                              <input class="form-control" id="telefono" name="telefono" type="text" value="<?php echo $registro['telefono'] ?>"  required />
                          </div>
                          <div class="col-12 col-sm-4">
                           <label> E-mail: </label> <!-- Etiqueta de la Duracion -->
                           <!-- Cuadro de texto para ingresar la duración -->
                           <input class="form-control" id="email" name="email" type="text" value="<?php echo $registro['email'] ?>"  required />
                        </div>
                  </div>
                  <!-- Espacio entre el diseño y los botones -->
                  <p></p>

                  <!-- Botón de Regresar con acción a la pantralla de Grados -->
                  <a href="<?php echo base_url(); ?>profesores" class="btn btn-outline-primary"><i class="fa-solid fa-arrow-left fa-fade"></i> Regresar</a>
                  <!-- Botón de Guardar -->
                  <button type="submit" class="btn btn-outline-success"><i class="fa-regular fa-floppy-disk fa-fade"></i></i> Guardar</button>
               </div>
            </div>
         </form>
      </div>
   </main>