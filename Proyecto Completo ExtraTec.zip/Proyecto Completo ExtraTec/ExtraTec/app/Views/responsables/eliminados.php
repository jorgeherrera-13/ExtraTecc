<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h2 class="mt-4"><b><?php echo $titulo; ?></b></h2>
            <div>
                <p>
                    <a href="<?php echo base_url(); ?>/profesores" class="btn btn-outline-primary btn"><i class="fa-solid fa-arrow-left fa-fade"></i> Regresar </a>
                </p>
            </div>
            <div class="card mb-4">
                <div class="card-body">
                    <table id="datatablesSimple">
                        <thead>
                            <tr>
                            <th>id</th>
                                <th>Nombre</th>
                                <th>Apellido Paterno</th>
                                <th>Apellido Materno</th>
                                <th>Telefono</th>
                                <th>E-mail</th>
                                <th></th>
                            </tr>
                        </thead>

                        <tbody>
                            
                            <?php foreach ($datos as $registro) { ?>
                                <tr>
                                    <td><?php echo $registro['idprofesor']; ?> </td>
                                    <td><?php echo $registro['nombre']; ?> </td>
                                    <td><?php echo $registro['apellidopri']; ?> </td>
                                    <td><?php echo $registro['apellidoseg']; ?> </td>
                                    <td><?php echo $registro['telefono']; ?> </td>
                                    <td><?php echo $registro['email']; ?> </td>
                                    <td>
                                        <button data-bs-id="<?php echo $registro['idprofesor']; ?>" data-bs-nombre="<?php echo $registro['nombre']; ?>" data-bs-toggle="modal" data-bs-target="#backModal" rel='tooltip' data-placement="top" class="btn btn-success mt-1"><i class="fas fa-undo"></i> Restaurar </button>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>



    <!-- **************************** 
    ************ Modal Reactivar ************
     ****************************-->
    <div class="modal fade" id="backModal" tabindex="-1" role="dialog" aria-labelledby="backModal" aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">¿Desea activar al Profesor <b><span></span>?</b></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-footer">
                    <form id="backForm" data-bs-action="<?php echo base_url() . 'profesores/reingresar/' ?>" action="" method="post">
                        <button type="submit" class="btn btn-primary">Si</button>
                    </form>
                    <button class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </div>
    </div>