<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('programas', 'Programas::index');
$routes->get('programas/nuevo', 'Programas::nuevo');
$routes->post('programas/insertar', 'Programas::insertar');
$routes->get('programas/editar/(:num)', 'Programas::editar/$1');
$routes->post('programas/actualizar', 'Programas::actualizar');
$routes->post('programas/eliminar/(:num)', 'Programas::eliminar/$1');
$routes->get('programas/eliminados', 'Programas::eliminados');
$routes->post('programas/reingresar/(:num)', 'Programas::reingresar/$1');



$routes->get('cursos', 'Cursos::index');
$routes->get('cursos/nuevo', 'Cursos::nuevo');
$routes->post('cursos/insertar', 'Cursos::insertar');
$routes->get('cursos/editar/(:num)', 'Cursos::editar/$1');
$routes->post('cursos/actualizar', 'Cursos::actualizar');
$routes->post('cursos/eliminar/(:num)', 'Cursos::eliminar/$1');
$routes->get('cursos/eliminados', 'Cursos::eliminados');
$routes->post('cursos/reingresar/(:num)', 'Cursos::reingresar/$1');



$routes->get('profesores', 'Profesores::index');
$routes->get('profesores/nuevo', 'Profesores::nuevo');
$routes->post('profesores/insertar', 'Profesores::insertar');
$routes->get('profesores/editar/(:num)', 'Profesores::editar/$1');
$routes->post('profesores/actualizar', 'Profesores::actualizar');
$routes->post('profesores/eliminar/(:num)', 'Profesores::eliminar/$1');
$routes->get('profesores/eliminados', 'Profesores::eliminados');
$routes->post('profesores/reingresar/(:num)', 'Profesores::reingresar/$1');

$routes->get('estados', 'Estados::index');
$routes->get('estados/nuevo', 'Estados::nuevo');
$routes->post('estados/insertar', 'Estados::insertar');
$routes->get('estados/editar/(:num)', 'Estados::editar/$1');
$routes->post('estados/actualizar', 'Estados::actualizar');
$routes->post('estados/eliminar/(:num)', 'Estados::eliminar/$1');
$routes->get('estados/eliminados', 'Estados::eliminados');
$routes->post('estados/reingresar/(:num)', 'Estados::reingresar/$1');

$routes->get('alumnos', 'Alumnos::index');
$routes->get('alumnos/nuevo', 'Alumnos::nuevo');
$routes->post('alumnos/insertar', 'Alumnos::insertar');
$routes->get('alumnos/editar/(:num)', 'Alumnos::editar/$1');
$routes->post('alumnos/actualizar', 'Alumnos::actualizar');
$routes->post('alumnos/eliminar/(:num)', 'Alumnos::eliminar/$1');
$routes->get('alumnos/eliminados', 'Alumnos::eliminados');
$routes->post('alumnos/reingresar/(:num)', 'Alumnos::reingresar/$1');