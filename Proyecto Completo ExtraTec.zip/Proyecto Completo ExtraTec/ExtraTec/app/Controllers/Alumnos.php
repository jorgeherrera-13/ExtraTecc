<?php

namespace App\Controllers;


use App\Models\alumnosModel;
use App\Models\estadosModel;
use App\Models\ProgramasModel;

use App\Controllers\BaseController;

class Alumnos extends BaseController
{

   protected $alumnos;
   protected $estados;
   protected $programas;

   public function __construct()
   {
      $this->alumnos = new alumnosModel();
      $this->estados = new estadosModel();
      $this->programas = new programasModel();

      helper(['form']);
   }

   public function index($activo = 1)
   {
      $estados = $this->estados->WHERE('activo', $activo)->findAll();
      $alumnos = $this->alumnos->WHERE('activo', $activo)->findAll();
      $programas = $this->programas->WHERE('activo', $activo)->findAll();

      $data = ['titulo' => 'Participantes', 'datos' => $alumnos, 'estados' => $estados, 'programas' => $programas];

      echo view('header');
      echo view('alumnos/alumnos', $data);
      echo view('footer');
   }

   public function nuevo()
   {

      $estados = $this->estados->WHERE('activo', 1)->findAll();
      $programas = $this->programas->WHERE('activo', 1)->findAll();


      $data = ['titulo' => 'Nuevo alumno', 'estados' => $estados, 'programas' => $programas];

      echo view('header');
      echo view('alumnos/nuevo', $data);
      echo view('footer');
   }

   public function insertar()
   {

      $method = $_SERVER['REQUEST_METHOD'];
      if ($method == "POST") {

         $this->alumnos->save([
            'nombre' => $this->request->getPost('nombre'),
            'primerapellido' => $this->request->getPost('primerapellido'),
            'segundoapellido' => $this->request->getPost('segundoapellido'),
            'fechanacimiento' => $this->request->getPost('fechanacimiento'),
            'genero' => $this->request->getPost('genero'),
            'email' => $this->request->getPost('email'),
            'telefono' => $this->request->getPost('telefono'),
            'idestado' => $this->request->getPost('idestado'),
            'fechaingreso' => $this->request->getPost('fechaingreso'),
            'idprograma' => $this->request->getPost('idprograma')
         ]);
         return redirect()->to(base_url() . 'alumnos');
      } else {

         $data = ['titulo' => 'Nuevo alumno',  'validation' => $this->validator];
         echo view('header');
         echo view('alumnos/nuevo', $data);
         echo view('footer');
      }
   }

   public function editar($id)
   {
      $alumnos = $this->alumnos->where('idalumno', $id)->first();
      $estados = $this->estados->WHERE('activo', 1)->findAll();
      $programas = $this->programas->WHERE('activo', 1)->findAll();


      $data = ['titulo' => 'Editar alumno','alumnos' => $alumnos, 'estados' => $estados, 'programas' => $programas];


      // FrontEnd
      echo view('header');
      echo view('alumnos/editar', $data);
      echo view('footer');
   }

   // Método para actualizar un registro a la tabla de Libros
   public function actualizar()
   {
      $method = $_SERVER['REQUEST_METHOD'];
      if ($method == "POST") {
         // Recibe el id que estamos enviando como oculto desde la pantalla de Editar
         $id = (int) $this->request->getPost('id');
         if ($id > 0) {
            $this->alumnos->update(
               $id,
               [
                'nombre' => $this->request->getPost('nombre'),
                'primerapellido' => $this->request->getPost('primerapellido'),
                'segundoapellido' => $this->request->getPost('segundoapellido'),
                'fechanacimiento' => $this->request->getPost('fechanacimiento'),
                'genero' => $this->request->getPost('genero'),
                'email' => $this->request->getPost('email'),
                'telefono' => $this->request->getPost('telefono'),
                'idestado' => $this->request->getPost('idestado'),
                'fechaingreso' => $this->request->getPost('fechaingreso'),
                'idprograma' => $this->request->getPost('idprograma')
               ]
            );
         } else {
            echo "El registro no existe en la base de datos. No se puede actualizar.";

         }
            return redirect()->to(base_url() . '/alumnos');
      } else {

         return $this->editar($this->request->getPost('id'), $this->validator);
      }
   }

   // Método para dar de baja un registro a la tabla de libros
   public function eliminar($id)
   {
      // Recibe el id que estamos enviando como oculto desde la pantalla de Editar
      $this->alumnos->update($id, ['activo' => 0]);
      return redirect()->to(base_url() . '/alumnos');
   }

   // Método para mostrar las carreras borradas
   public function eliminados($activo = 0)
   {
      $estados = $this->estados->WHERE('activo', 1)->findAll();
      $alumnos = $this->alumnos->WHERE('activo', $activo)->findAll();
      $programas = $this->programas->WHERE('activo', 1)->findAll();

      $data = ['titulo' => 'Libros eliminados', 'datos' => $alumnos, 'estados' => $estados, 'programas' => $programas];

      // FrontEnd
      echo view('header');
      echo view('alumnos/eliminados', $data);
      echo view('footer');
   }

   // Método para dar de baja un registro a la tabla de carreras
   public function reingresar($id)
   {
      // Recibe el id que estamos enviando como oculto desde la vista de Editar
      $this->alumnos->update($id, ['activo' => 1]);
      return redirect()->to(base_url() . '/alumnos');
   }
}