<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\estadosModel;

class estados extends BaseController
{
    protected $estados;

    public function __construct()
    {
        $this->estados = new estadosModel();
        helper(['form']);
    }

    public function index($estados = 1)
    {
        $estados = $this->estados->where('activo', $estados)->findAll();
        $data = ['titulo' => 'Estatus', 'estados' => $estados];
    
        echo view('header');
        echo view('estados/estados', $data);
        echo view('footer');
    }
    
    public function nuevo()
    {
        $data = ['titulo' => 'Nuevo Estado'];

        echo view('header');
        echo view('estados/nuevo', $data);
        echo view('footer');
    }

    public function insertar()
    {
        $method = $_SERVER['REQUEST_METHOD'];

        if ($method == "POST") {
            $this->estados->save([
                'estado' => $this->request->getPost('estado')
            ]);
            return redirect()->to(base_url() . 'estados');
        } else {
            $data = ['titulo' => 'Nuevo Estado'];
            echo view('header');
            echo view('estados/nuevo', $data);
            echo view('footer');
        }
    }

    public function editar($id)
    {
        $estados = $this->estados->where('idestado', $id)->first();
        $data = ['titulo' => 'Editar Estado', 'registro' => $estados];
    
        echo view('header');
        echo view('estados/editar', $data);
        echo view('footer');
    }
    
    public function actualizar()
    {
        $method = $_SERVER['REQUEST_METHOD'];

        if ($method == "POST") {
            $this->estados->update(
                $this->request->getPost('IDestado'),
                [
                'estado' => $this->request->getPost('estado')
                ]
            );
            return redirect()->to(base_url() . '/estados');
        } else {
            return $this->editar($this->request->getPost('idestado'));
        }
    }

    public function eliminar($id)
    {
        $this->estados->update($id, ['activo' => 0]);
        return redirect()->to(base_url() . '/estados');
    }

    public function eliminados($activo = 0)
    {
        $estados = $this->estados->where('activo', $activo)->findAll();
        $data = ['titulo' => 'Estados eliminados', 'datos' => $estados];
    
        echo view('header');
        echo view('estados/eliminados', $data);
        echo view('footer');
    }
    
    public function reingresar($id)
    {
        $this->estados->update($id, ['activo' => 1]);
        return redirect()->to(base_url() . '/estados');
    }
}