<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\programasModel;

class Programas extends BaseController
{
    protected $programas;
    protected $reglas;

    public function __construct()
    {
        $this->programas = new programasModel();
        helper(['form']);
        // Reglas para validación de los campos
        $this->reglas = [
            //Nombre que tiene en la vista (view)
            'programa' => [
                'rules' => 'required|is_unique[programas.nombreprograma]',
                'errors' => [
                    'required' => 'El campo programa es obligatorio.',
                    'is_unique' => 'El registro ya existe en la base de datos'
                ]
            ],
            'codigo' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'El campo Código es obligatorio.'
                ]
            ],
            'duracion' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'El campo Duración es obligatorio.'
                ]
            ]
        ];
    }

    public function index($programas = 1)
    {
        $programas = $this->programas->where('activo', $programas)->findAll();
        $data = ['titulo' => 'Actividades', 'programas' => $programas];

        echo view('header');
        echo view('programas/programas', $data);
        echo view('footer');
    }

    public function nuevo()
    {
        $data = ['titulo' => 'Nuevo Programa'];

        echo view('header');
        echo view('programas/nuevo', $data);
        echo view('footer');
    }

    public function insertar()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method == "POST") {
            // Verificar si es el primer registro
            $existeRegistro = $this->programas->countAllResults();

            // Ajustar las reglas según sea necesario
            $reglas = $this->reglas;
            if ($existeRegistro == 0) {
                unset($reglas['Programas']['rules']['is_unique']);
            }

            if ($this->validate($reglas)) {
                $this->programas->save([
                    //Campo BD                   Vista
                    'nombreprograma' => $this->request->getPost('programa'),
                    'codigoprograma' => $this->request->getPost('codigo'),
                    'duracion' => $this->request->getPost('duracion')
                ]);
                return redirect()->to(base_url() . 'programas');
            } else {
                $data = ['titulo' => 'Nuevo Programa', 'validation' => $this->validator];
                echo view('header');
                echo view('programas/nuevo', $data);
                echo view('footer');
            }
        }
    }

    public function editar($id)
    {
        $programas = $this->programas->where('idprograma', $id)->first();
        $data = ['titulo' => 'Editar Programa', 'registro' => $programas];

        echo view('header');
        echo view('programas/editar', $data);
        echo view('footer');
    }

    public function actualizar()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method == "POST") {
            // Recibe el id que estamos enviando como oculto desde la pantalla de Editar
            $this->programas->update(
                $this->request->getPost('IDprograma'),
                [   //Campo Base de datos                       //Campo de texto
                    'nombreprograma' => $this->request->getPost('nombre'),
                    'codigoprograma' => $this->request->getPost('codigoprograma'),
                    'duracion' => $this->request->getPost('duracion')
                ]
            );
            return redirect()->to(base_url() . '/programas');
        } else {
            return $this->editar($this->request->getPost('IDprograma'));
        }
    }

    public function eliminar($id)
    {
        $this->programas->update($id, ['activo' => 0]);
        return redirect()->to(base_url() . '/programas');
    }

    public function eliminados($activo = 0)
    {
        $programas = $this->programas->where('activo', $activo)->findAll();
        $data = ['titulo' => 'Programas eliminados', 'registros' => $programas];

        echo view('header');
        echo view('programas/eliminados', $data);
        echo view('footer');
    }


    public function reingresar($id)
    {
        $this->programas->update($id, ['activo' => 1]);
        return redirect()->to(base_url() . '/programas');
    }
}
