<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\cursosModel;
use App\Models\programasModel;
use App\Models\profesoresModel;

class Cursos extends BaseController
{
    protected $cursos;
    protected $programas;
    protected $profesores;

    public function __construct()
    {
        $this->cursos = new cursosModel();
        $this->programas = new programasModel();
        $this->profesores = new profesoresModel();

        helper(['form']);
    }

    public function index($activo = 1)
    {
        $cursos = $this->cursos->where('activo', $activo)->findAll();
        $programas = $this->programas->where('activo', $activo)->findAll();
        $profesores = $this->profesores->where('activo', $activo)->findAll();

        $data = ['titulo' => 'Sesiones', 'cursos' => $cursos, 'programas' => $programas, 'profesores' => $profesores];
    
        echo view('header');
        echo view('cursos/cursos', $data);
        echo view('footer');
    }
    
    public function nuevo()
    {
        $programas = $this->programas->WHERE('activo', 1)->findAll();
        $profesores = $this->profesores->WHERE('activo', 1)->findAll();

        $data = ['titulo' => 'Nuevo Curso', 'programas' => $programas, 'profesores' => $profesores];

        echo view('header');
        echo view('cursos/nuevo', $data);
        echo view('footer');
    }

    public function insertar()
    {
        $method = $_SERVER['REQUEST_METHOD'];

        if ($method == "POST") {
            $this->cursos->save([
                'nombrecurso' => $this->request->getPost('nombrecurso'),
                'codigcurso' => $this->request->getPost('codigcurso'),
                'idprograma' => $this->request->getPost('idprograma'),
                'idprofesor' => $this->request->getPost('idprofesor'),
            ]);
            return redirect()->to(base_url() . 'cursos');
        } else {
            $data = ['titulo' => 'Nuevo Curso'];
            echo view('header');
            echo view('cursos/nuevo', $data);
            echo view('footer');
        }
    }

    public function editar($id)
    {
        $cursos = $this->cursos->where('idcurso', $id)->first();
        $programas = $this->programas->WHERE('activo', 1)->findAll();
        $profesores = $this->profesores->WHERE('activo', 1)->findAll();

        $data = ['titulo' => 'Editar Curso', 'registro' => $cursos, 'programas' => $programas, 'profesores' => $profesores];
    
        echo view('header');
        echo view('cursos/editar', $data);
        echo view('footer');
    }
    
    public function actualizar()
    {
        $method = $_SERVER['REQUEST_METHOD'];

        if ($method == "POST") {
            $this->cursos->update(
                $this->request->getPost('IDcurso'),
                [
                'nombrecurso' => $this->request->getPost('nombrecurso'),
                'codigcurso' => $this->request->getPost('codigcurso'),
                'idprograma' => $this->request->getPost('idprograma'),
                'idprofesor' => $this->request->getPost('idprofesor'),
                ]
            );
            return redirect()->to(base_url() . '/cursos');
        } else {
            return $this->editar($this->request->getPost('idcurso'));
        }
    }

    public function eliminar($id)
    {
        $this->cursos->update($id, ['activo' => 0]);
        return redirect()->to(base_url() . '/cursos');
    }

    public function eliminados($activo = 0)
    {
        $cursos = $this->cursos->where('activo', $activo)->findAll();
        $programas = $this->programas->WHERE('activo', 1)->findAll();
        $profesores = $this->profesores->WHERE('activo', 1)->findAll();
        
        $data = ['titulo' => 'Cursos eliminados', 'datos' => $cursos];
    
        echo view('header');
        echo view('cursos/eliminados', $data);
        echo view('footer');
    }
    
    public function reingresar($id)
    {
        $this->cursos->update($id, ['activo' => 1]);
        return redirect()->to(base_url() . '/cursos');
    }
}
