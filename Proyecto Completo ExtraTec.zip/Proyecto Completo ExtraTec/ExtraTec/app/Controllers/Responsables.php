<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\profesoresModel;

class profesores extends BaseController
{
    protected $profesores;

    public function __construct()
    {
        $this->profesores = new profesoresModel();
        helper(['form']);
    }

    public function index($profesores = 1)
    {
        $profesores = $this->profesores->where('activo', $profesores)->findAll();
        $data = ['titulo' => 'Responsables', 'profesores' => $profesores];
    
        echo view('header');
        echo view('profesores/profesores', $data);
        echo view('footer');
    }
    
    public function nuevo()
    {
        $data = ['titulo' => 'Nuevo Profesor'];

        echo view('header');
        echo view('profesores/nuevo', $data);
        echo view('footer');
    }

    public function insertar()
    {
        $method = $_SERVER['REQUEST_METHOD'];

        if ($method == "POST") {
            $this->profesores->save([
                'nombre' => $this->request->getPost('nombre'),
                'apellidopri' => $this->request->getPost('apellidopri'),
                'apellidoseg' => $this->request->getPost('apellidoseg'),
                'telefono' => $this->request->getPost('telefono'),
                'email' => $this->request->getPost('email'),
            ]);
            return redirect()->to(base_url() . 'profesores');
        } else {
            $data = ['titulo' => 'Nuevo Profesor'];
            echo view('header');
            echo view('profesores/nuevo', $data);
            echo view('footer');
        }
    }

    public function editar($id)
    {
        $profesores = $this->profesores->where('idprofesor', $id)->first();
        $data = ['titulo' => 'Editar Profesor', 'registro' => $profesores];
    
        echo view('header');
        echo view('profesores/editar', $data);
        echo view('footer');
    }
    
    public function actualizar()
    {
        $method = $_SERVER['REQUEST_METHOD'];

        if ($method == "POST") {
            $this->profesores->update(
                $this->request->getPost('IDprofesor'),
                [
                'nombre' => $this->request->getPost('nombre'),
                'apellidopri' => $this->request->getPost('PA'),
                'apellidoseg' => $this->request->getPost('apellidoseg'),
                'telefono' => $this->request->getPost('telefono'),
                'email' => $this->request->getPost('email'),
                ]
            );
            return redirect()->to(base_url() . '/profesores');
        } else {
            return $this->editar($this->request->getPost('idprofesor'));
        }
    }

    public function eliminar($id)
    {
        $this->profesores->update($id, ['activo' => 0]);
        return redirect()->to(base_url() . '/profesores');
    }

    public function eliminados($activo = 0)
    {
        $profesores = $this->profesores->where('activo', $activo)->findAll();
        $data = ['titulo' => 'Profesores eliminados', 'datos' => $profesores];
    
        echo view('header');
        echo view('profesores/eliminados', $data);
        echo view('footer');
    }
    
    public function reingresar($id)
    {
        $this->profesores->update($id, ['activo' => 1]);
        return redirect()->to(base_url() . '/profesores');
    }
}
