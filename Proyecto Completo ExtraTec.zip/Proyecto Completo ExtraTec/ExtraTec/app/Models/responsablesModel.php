<?php

namespace App\Models;

use CodeIgniter\Model;
use CodeIgniter\Models;

class profesoresModel extends Model
{
    // Define el nombre de la tabla en la base de datos
    protected $table = 'profesores';
    
    // Define la clave primaria de la tabla
    protected $primaryKey = 'idprofesor';

    // Especifica el tipo de dato que se devolverá al recuperar registros (en este caso, un array)
    protected $returnType = 'array';
    
    // Desactiva la funcionalidad de eliminación suave (soft deletes)
    protected $useSoftDeletes = false;

    // Define los campos de la tabla que se pueden modificar
    protected $allowedFields = ['nombre','apellidopri', 'apellidoseg', 'telefono', 'email', 'activo'];

    // Desactiva el uso automático de timestamps
    protected $useTimestamps = false;
    
    // Define el nombre del campo para la fecha de creación (no se usa porque $useTimestamps es false)
    protected $createdField = 'fecha_alta';
    
    // Define el nombre del campo para la fecha de actualización (no se usa porque $useTimestamps es false)
    protected $updateField = 'fecha_edicion';
    
    // Define el nombre del campo para la fecha de eliminación (no se usa porque $useSoftDeletes es false)
    protected $deleteField = 'delete_at';

    // Array para definir reglas de validación (está vacío en este caso)
    protected $validationRules = [];
    
    // Array para definir mensajes de validación personalizados (está vacío en este caso)
    protected $validationMessages = [];
    
    // Determina si se debe saltar la validación (false significa que no se salta)
    protected $skipValidation = false;
}

?>